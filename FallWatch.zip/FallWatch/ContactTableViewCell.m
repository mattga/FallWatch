//
//  ContactTableViewCell.m
//  FallWatch
//
//  Created by Matthew Gardner on 2/20/16.
//  Copyright © 2016 Matthew Gardner. All rights reserved.
//

#import "ContactTableViewCell.h"

@implementation ContactTableViewCell

@end
