//
//  FWCOntact.m
//  FallWatch
//
//  Created by Matthew Gardner on 2/20/16.
//  Copyright © 2016 Matthew Gardner. All rights reserved.
//

#import "FWContact.h"

@implementation FWContact

@end
