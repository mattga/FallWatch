//
//  ContactTableViewController.h
//  FallWatch
//
//  Created by Matthew Gardner on 2/20/16.
//  Copyright © 2016 Matthew Gardner. All rights reserved.
//

@import Contacts;

#import <UIKit/UIKit.h>

@interface ContactTableViewController : UITableViewController <UISearchResultsUpdating>

@end
